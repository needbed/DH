"""
URL configuration for API project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework_simplejwt.views import (TokenObtainPairView,TokenRefreshView,TokenVerifyView)
from api.views import (
    inscription_page,
    RegisterView,
    user_list,login_view,
    get_email,
    set_staff_and_superuser,
)
from django.contrib.auth import views as auth_views


urlpatterns = [
    path("admin/", admin.site.urls, name="connect"),
    path('user/login/', login_view, name="login"),
    
    path("api/token/", TokenObtainPairView.as_view(), name="token_obtain_pair"),
    path("api/token/refresh/", TokenRefreshView.as_view(), name="token_refresh"),
    path("api/token/verify/", TokenVerifyView.as_view(), name="token_verify"),
    
    path('inscription/register/', RegisterView.as_view(), name="inscription_register_api"),
    path('api/user/list/', user_list, name='users'),
    path('inscription/', inscription_page, name="inscription"),
    
    path('change/', auth_views.PasswordChangeView.as_view(), name="password_change"),
    path('change/done/', auth_views.PasswordChangeDoneView.as_view(), name="password_change_done"),
    
    path('getEmail/', get_email, name="mail"),
    path('set-staff-superuser/', set_staff_and_superuser, name="set_status"),
    
    # path('forget_password/', forget_password, name='forget_password'),
    # path('reset_password/<str:token>/', reset_password, name='reset_password'),
]




