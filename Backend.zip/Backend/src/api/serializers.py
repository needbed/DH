from rest_framework import serializers
from .models import (
    UserProfile,
    Hotel,
    Chambre,
    Service,
    Reservation,
    Compte,
    Transaction,
    Produit,
    CommandeClient,
    LigneCommandeClient,
    CommandeFournisseur,
    LigneCommandeFournisseur,
    StockMagasin,
    StockCuisine,
    InventaireMagasin,
    LigneInventaireMagasin,
    InventaireCuisine,
    LigneInventaireCuisine
)


class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = '__all__'


class HotelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Hotel
        fields = '__all__'


class ChambreSerializer(serializers.ModelSerializer):
    class Meta:
        model = Chambre
        fields = '__all__'


class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = '__all__'


class ReservationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reservation
        fields = '__all__'


class CompteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Compte
        fields = '__all__'


class TransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transaction
        fields = '__all__'


class ProduitSerializer(serializers.ModelSerializer):
    class Meta:
        model = Produit
        fields = '__all__'


class LigneCommandeClientSerializer(serializers.ModelSerializer):
    class Meta:
        model = LigneCommandeClient
        fields = '__all__'


class CommandeClientSerializer(serializers.ModelSerializer):
    lignes_commande = LigneCommandeClientSerializer(many=True)

    class Meta:
        model = CommandeClient
        fields = '__all__'


class LigneCommandeFournisseurSerializer(serializers.ModelSerializer):
    class Meta:
        model = LigneCommandeFournisseur
        fields = '__all__'


class CommandeFournisseurSerializer(serializers.ModelSerializer):
    lignes_commande = LigneCommandeFournisseurSerializer(many=True)

    class Meta:
        model = CommandeFournisseur
        fields = '__all__'


class StockMagasinSerializer(serializers.ModelSerializer):
    class Meta:
        model = StockMagasin
        fields = '__all__'


class StockCuisineSerializer(serializers.ModelSerializer):
    class Meta:
        model = StockCuisine
        fields = '__all__'


class LigneInventaireMagasinSerializer(serializers.ModelSerializer):
    class Meta:
        model = LigneInventaireMagasin
        fields = '__all__'


class InventaireMagasinSerializer(serializers.ModelSerializer):
    lignes_inventaire = LigneInventaireMagasinSerializer(many=True)

    class Meta:
        model = InventaireMagasin
        fields = '__all__'


class LigneInventaireCuisineSerializer(serializers.ModelSerializer):
    class Meta:
        model = LigneInventaireCuisine
        fields = '__all__'


class InventaireCuisineSerializer(serializers.ModelSerializer):
    lignes_inventaire = LigneInventaireCuisineSerializer(many=True)

    class Meta:
        model = InventaireCuisine
        fields = '__all__'
