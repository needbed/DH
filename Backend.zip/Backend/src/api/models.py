from django.db import models
from django.contrib.auth import get_user_model
from django.utils import timezone




# Gestion des profiles
class UserProfile(models.Model):
    user = models.OneToOneField(get_user_model(), on_delete=models.CASCADE, default=1)
    matricule = models.CharField(max_length=20, unique=True, editable=False, default=None)
    ifu = models.CharField(max_length=20, default=None)
    photo = models.ImageField(upload_to='users/', null=True, blank=True)
    phone_number = models.CharField(max_length=20, default=None)
    address = models.TextField(default=None)
    speciality = models.CharField(max_length=100, default=None)
    years_of_experience = models.IntegerField(default=0)
    grade = models.CharField(max_length=50, default=None)
    job_title = models.CharField(max_length=100, default="Cuisinier")

    def __str__(self):
        return self.user.username




# Gestion des hôtels
class Hotel(models.Model):
    nom = models.CharField(max_length=255, default="Un nom par défaut")
    description = models.TextField(default="Une description par défaut")

    def __str__(self):
        return self.nom




# Gestion des chambres
class Chambre(models.Model):
    TYPE_CHOICES = [
        ('ORD', 'Ordinaire'),
        ('VEN', 'Ventilé'),
        ('CLI', 'Climatisé'),
        ('SUI', 'Suite'),
        ('VIP', 'VIP'),
    ]

    nom = models.CharField(max_length=255)
    description = models.TextField()
    type_chambre = models.CharField(max_length=3, choices=TYPE_CHOICES)
    prix = models.DecimalField(max_digits=8, decimal_places=2)
    nombre_lits = models.IntegerField()
    hotel = models.ForeignKey(Hotel, on_delete=models.CASCADE)

    def __str__(self):
        return self.nom




# Gestion des types de services
class Service(models.Model):
    nom = models.CharField(max_length=255, default=None)
    prix = models.DecimalField(max_digits=8, decimal_places=2, default=0.0)

    def __str__(self):
        return self.nom




# Gestion des réservations
class Reservation(models.Model):
    utilisateur = models.ForeignKey(UserProfile, on_delete=models.CASCADE, default=None)
    chambre = models.ForeignKey(Chambre, on_delete=models.CASCADE, default=None)
    services = models.ManyToManyField(Service)
    date_reservation = models.DateField(default=timezone.now)

    def __str__(self):
        return f"Réservation de {self.utilisateur.user.username} pour la chambre {self.chambre.nom}"




# Gestion de la comptabilité
class Compte(models.Model):
    numero = models.CharField(max_length=20, unique=True)
    nom = models.CharField(max_length=255)

    def __str__(self):
        return self.nom




class Transaction(models.Model):
    compte = models.ForeignKey(Compte, on_delete=models.CASCADE)
    date = models.DateField(default=timezone.now)
    montant = models.DecimalField(max_digits=8, decimal_places=2)
    description = models.TextField()

    def __str__(self):
        return f"Transaction de {self.montant} pour le compte {self.compte.nom}"




# Gestion des Commandes clients et fournisseurs
class Produit(models.Model):
    nom = models.CharField(max_length=255)
    description = models.TextField()

    def __str__(self):
        return self.nom




class CommandeClient(models.Model):
    client = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    produits = models.ManyToManyField(Produit, through='LigneCommandeClient')
    date_commande = models.DateField(default=timezone.now)

    def __str__(self):
        return f"Commande du client {self.client.user.username}"




class LigneCommandeClient(models.Model):
    commande = models.ForeignKey(CommandeClient, on_delete=models.CASCADE)
    produit = models.ForeignKey(Produit, on_delete=models.CASCADE)
    quantite = models.IntegerField()
    prix_unitaire = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return f"Ligne de commande {self.commande.id} - {self.produit.nom}"




class CommandeFournisseur(models.Model):
    fournisseur = models.CharField(max_length=255)
    produits = models.ManyToManyField(Produit, through='LigneCommandeFournisseur')
    date_commande = models.DateField(default=timezone.now)

    def __str__(self):
        return f"Commande au fournisseur {self.fournisseur}"




class LigneCommandeFournisseur(models.Model):
    commande = models.ForeignKey(CommandeFournisseur, on_delete=models.CASCADE)
    produit = models.ForeignKey(Produit, on_delete=models.CASCADE)
    quantite = models.IntegerField()
    prix_unitaire = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return f"Ligne de commande {self.commande.id} - {self.produit.nom}"




# Gestion des stocks cuisine et magasin
class StockMagasin(models.Model):
    produit = models.OneToOneField(Produit, on_delete=models.CASCADE)
    quantite = models.IntegerField()

    def __str__(self):
        return f"Stock magasin - {self.produit.nom}"




class StockCuisine(models.Model):
    produit = models.OneToOneField(Produit, on_delete=models.CASCADE)
    quantite = models.IntegerField()

    def __str__(self):
        return f"Stock cuisine - {self.produit.nom}"




# Inventaire cuisine et magasin
class InventaireMagasin(models.Model):
    date = models.DateField(default=timezone.now)
    produits = models.ManyToManyField(Produit, through='LigneInventaireMagasin')

    def __str__(self):
        return f"Inventaire magasin du {self.date}"




class LigneInventaireMagasin(models.Model):
    inventaire = models.ForeignKey(InventaireMagasin, on_delete=models.CASCADE)
    produit = models.ForeignKey(Produit, on_delete=models.CASCADE)
    quantite = models.IntegerField()

    def __str__(self):
        return f"Ligne inventaire magasin {self.inventaire.id} - {self.produit.nom}"




class InventaireCuisine(models.Model):
    date = models.DateField(default=timezone.now)
    produits = models.ManyToManyField(Produit, through='LigneInventaireCuisine')

    def __str__(self):
        return f"Inventaire cuisine du {self.date}"




class LigneInventaireCuisine(models.Model):
    inventaire = models.ForeignKey(InventaireCuisine, on_delete=models.CASCADE)
    produit = models.ForeignKey(Produit, on_delete=models.CASCADE)
    quantite = models.IntegerField()

    def __str__(self):
        return f"Ligne inventaire cuisine {self.inventaire.id} - {self.produit.nom}"








