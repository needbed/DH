"""
URL configuration for API project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework_simplejwt.views import (TokenObtainPairView,TokenRefreshView,TokenVerifyView)
from api.views import (
    inscription_page,
    RegisterView,
    user_list,
    login_view,
    get_email,
    set_staff_and_superuser,
    disable_user,
    get_user_profiles,
    create_user_profile,
    get_hotels,
    create_hotel,
    get_chambres,
    create_chambre,
    get_services,
    create_service,
    get_reservations,
    create_reservation,
    get_comptes,
    create_compte,
    get_transactions,
    create_transaction,
    get_produits,
    create_produit,
    get_commandes_clients,
    create_commande_client,
    get_lignes_commande_client,
    create_ligne_commande_client,
    get_commandes_fournisseurs,
    create_commande_fournisseur,
    get_stocks_magasin,
    create_stock_magasin,
    get_stocks_cuisine,
    create_stock_cuisine,
    get_inventaires_magasin,
    create_inventaire_magasin,
    get_inventaires_cuisine,
    create_inventaire_cuisine,
    get_lignes_inventaire_magasin,
    create_ligne_inventaire_magasin,
    get_lignes_inventaire_cuisine,
    create_ligne_inventaire_cuisine,
)
from django.contrib.auth import views as auth_views


urlpatterns = [
    path("admin/", admin.site.urls, name="connect"),
    path('user/login/', login_view, name="login"),
    
    path("api/token/", TokenObtainPairView.as_view(), name="token_obtain_pair"),
    path("api/token/refresh/", TokenRefreshView.as_view(), name="token_refresh"),
    path("api/token/verify/", TokenVerifyView.as_view(), name="token_verify"),
    
    path('inscription/register/', RegisterView.as_view(), name="inscription_register_api"),
    path('api/user/list/', user_list, name='users'),
    path('inscription/', inscription_page, name="inscription"),
    
    path('change/', auth_views.PasswordChangeView.as_view(), name="password_change"),
    path('change/done/', auth_views.PasswordChangeDoneView.as_view(), name="password_change_done"),
    
    path('getEmail/', get_email, name="mail"),
    path('set-staff-superuser/', set_staff_and_superuser, name="set_status"),
    path('disable-user/', disable_user, name="disable-user"),
    
    
    
    path('api_get_userprofile/', get_user_profiles, name='user-profile'),
    path('api_create_userprofile/', create_user_profile, name='create-user-profile'),
    
    
    path('api_get_hotel/', get_hotels, name='hotel'),
    path('api_create_hotel/', create_hotel, name='create-hotel'),
    
    
    path('api_get_chambre/', get_chambres, name='chambre'),
    path('api_create_chambre/', create_chambre, name='create-chambre'),
    
    
    path('api_get_service/', get_services, name='service'),
    path('api_create_service/', create_service, name='create-service'),
    
    
    path('api_get_reservation/', get_reservations, name='reservation'),
    path('api_create_reservation/', create_reservation, name='create-reservation'),
    
    
    path('api_get_compte/', get_comptes, name='compte'),
    path('api_create_compte/', create_compte, name='create-compte'),
    
    
    path('api_get_transaction/', get_transactions, name='transaction'),
    path('api_create_transaction/', create_transaction, name='create-transaction'),
    
    
    path('api_get_produit/', get_produits, name='produit'),
    path('api_create_produit/',  create_produit, name='create-produit'),
    
    
    path('api_get_commandeClient/',  get_commandes_clients, name='commandeClient'),
    path('api_create_commandeClient/', create_commande_client, name='create-commandeClient'),
    
    
    path('api_get_ligneCommandeClient/', get_lignes_commande_client, name='ligneCommandeClient'),
    path('api_create_ligneCommandeClient/', create_ligne_commande_client, name='create-ligneCommandeclient'),
    
    
    path('api_get_commandeFournisseur/', get_commandes_fournisseurs, name='commandeFournisseur'),
    path('api_create_commandeFournisseur/', create_commande_fournisseur, name='commandeFournisseur'),
    
    
    path('api_get_stockMagasin/', get_stocks_magasin, name='stockMagasin'),
    path('api_create_stockMagasin/', create_stock_magasin, name='create-stockMagasin'),
    
    
    path('api_get_stockCuisine/', get_stocks_cuisine, name='stockCuisine'),
    path('api_create_stockCuisine/', create_stock_cuisine, name='create-stockCuisine'),
    
    
    path('api_get_inventaireMagasin/', get_inventaires_magasin, name='inventaireMagasin'),
    path('api_create_inventaireMagasin/', create_inventaire_magasin, name='create-inventaireMagasin'),
    
    
    path('api_get_inventaireCuisine/', get_inventaires_cuisine, name='inventaireCuisine'),
    path('api_create_inventaireCuisine/', create_inventaire_cuisine, name='create-inventaireCuisine'),
    
    
    path('api_get_ligneInventaireMagasin/', get_lignes_inventaire_magasin, name='ligneInventaireMagasin'),
    path('api_create_ligneInventaireMagasin/', create_ligne_inventaire_magasin, name='create-ligneInventaireMagasin'),
    
    
    path('api_get_ligneInventaireCuisine/', get_lignes_inventaire_cuisine, name='ligneInventaireCuisine'),
    path('api_create_ligneInventaireCuisine/', create_ligne_inventaire_cuisine, name='create-ligneInventaireCuisine'),
    
    
    
    # path('forget_password/', forget_password, name='forget_password'),
    # path('reset_password/<str:token>/', reset_password, name='reset_password'),
]





