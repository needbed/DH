from django.contrib import admin
from .models import (
    UserProfile,
    Hotel,
    Chambre,
    Service,
    Reservation,
    Compte,
    Transaction,
    Produit,
    LigneCommandeClient,
    LigneCommandeFournisseur,
    StockMagasin,
    StockCuisine,
    CommandeClient,
    LigneInventaireCuisine,
    LigneInventaireMagasin,
    CommandeFournisseur,
    InventaireCuisine,
    InventaireMagasin
)





admin.site.register(UserProfile)
admin.site.register(Hotel)
admin.site.register(Chambre)
admin.site.register(Service)
admin.site.register(Reservation)
admin.site.register(Compte)
admin.site.register(Transaction)
admin.site.register(Produit)
admin.site.register(CommandeClient)
admin.site.register(LigneCommandeClient)
admin.site.register(CommandeFournisseur)
admin.site.register(LigneCommandeFournisseur)
admin.site.register(StockMagasin)
admin.site.register(StockCuisine)
admin.site.register(InventaireCuisine)
admin.site.register(InventaireMagasin)
admin.site.register(LigneInventaireMagasin)
admin.site.register(LigneInventaireCuisine)


