from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from rest_framework import status, viewsets, permissions
from django.shortcuts import render, redirect
from rest_framework.decorators import api_view, action, permission_classes
from rest_framework.views import APIView
from rest_framework.response import Response
import random
import string
from django.urls import reverse

from .models import (
    UserProfile,
    Hotel,
    Chambre,
    Service,
    Reservation,
    Compte,
    Transaction,
    Produit,
    CommandeClient,
    LigneCommandeClient,
    CommandeFournisseur,
    LigneCommandeFournisseur,
    StockMagasin,
    StockCuisine,
    InventaireMagasin,
    LigneInventaireMagasin,
    InventaireCuisine,
    LigneInventaireCuisine
)

from .serializers import (ChambreSerializer, CommandeClientSerializer,
    CommandeFournisseurSerializer, CompteSerializer, HotelSerializer, InventaireCuisineSerializer,
    InventaireMagasinSerializer, LigneCommandeClientSerializer, LigneInventaireCuisineSerializer,
    LigneInventaireMagasinSerializer, ProduitSerializer, ReservationSerializer, ServiceSerializer,
    StockCuisineSerializer, StockMagasinSerializer, TransactionSerializer, UserProfileSerializer)




# TESTER ETAT DE LA CONNEXION
@api_view(['POST'])
def login_view(request):
    if request.method == 'POST':
        username = request.data.get('username')
        password = request.data.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return Response({'message': "Connexion réussie."}, status=status.HTTP_200_OK)
        else:
            return Response({'message': "Identifiant ou mot de passe incorrect."}, status=status.HTTP_401_UNAUTHORIZED)


# LISTE UTILISATEUR
@api_view(['GET'])
def user_list(request):
    if request.method == 'GET':
        users = User.objects.all()
        user_data = []
        for user in users:
            user_data.append({
                'Nom': user.username,
                'Mot de passe': user.password,
                'E-mail': user.email,
                'Equipe': user.is_staff,
                'Super': user.is_superuser
            })
        return Response(user_data, status=status.HTTP_200_OK)




# INSCRIPTION
class RegisterView(APIView):
    def post(self, request):
        if request.method == 'POST':
            username = request.POST.get('nom')
            password = request.POST.get('password')
            confirm = request.POST.get('confirm')
            email = request.POST.get('mail')

        valide = {}
        if password != confirm:
            valide['confirm'] = "Les mots de passe ne correspondent pas."

        if valide:
            return Response({'valide': valide}, status=status.HTTP_400_BAD_REQUEST)

        user = User.objects.create_user(
            username=username, password=password, email=email)
        return Response({'Message': 'Utilisateur créé avec succès.'}, status=status.HTTP_201_CREATED)


def inscription_page(request):
    return render(request, "api/inscription.html")


# MAIL UTILISATEUR
@api_view(['GET'])
def get_email(request):
    Users = User.objects.all()
    Email = []
    for i in Users:
        Email.append({
            "nom": i.username,
            "mail": i.email
        })
    return Response(Email, status=200)


# TRANSFORMER ETAT DE CHAQUE UTILISATEUR (STATUT-EQUIPE & STATUT-SUPERUSER)
@api_view(['GET'])
def set_staff_and_superuser(request):
    Users = User.objects.all()
    for user in Users:
        if not user.is_staff or not user.is_superuser:
            user.is_staff = True
            user.is_superuser = True
        user.save()
    return Response("Modification effectuée avec succès !", status=200)


@api_view(['GET','POST'])
def disable_user(request):
    users = User.objects.all()
    user_state = []
    for user in users:
        user_state.append({
            "id": user.id,
            "nom": user.username,
            "actif": user.is_active
        })
        
        taille = len(user_state)
        T = taille - 1
        
        if T >= 0:
            if user_state[T]["nom"] == "root":
                pass
            else:
                user_state[T]["actif"] = False
                T-=1
    return Response(user_state, status=200)


# GENERER MOT DE PASSE ALEATOIRE
def generate_random_password(length=10):
    characters = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(random.choice(characters) for _ in range(length))
    return password








# GET ET POST DE CHAQUE MODELE
# USERPROFILE
@api_view(['GET'])
def get_user_profiles(request):
    user_profiles = UserProfile.objects.all()
    serialized_profiles = UserProfileSerializer(user_profiles, many=True)
    return Response(serialized_profiles.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_user_profile(request):
    serialized_data = UserProfileSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# HOTEL
@api_view(['GET'])
def get_hotels(request):
    hotels = Hotel.objects.all()
    serialized_hotels = HotelSerializer(hotels, many=True)
    return Response(serialized_hotels.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_hotel(request):
    serialized_data = HotelSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# CHAMBRE
@api_view(['GET'])
def get_chambres(request):
    chambres = Chambre.objects.all()
    serialized_chambres = ChambreSerializer(chambres, many=True)
    return Response(serialized_chambres.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_chambre(request):
    serialized_data = ChambreSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# SERVICES
@api_view(['GET'])
def get_services(request):
    services = Service.objects.all()
    serialized_services = ServiceSerializer(services, many=True)
    return Response(serialized_services.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_service(request):
    serialized_data = ServiceSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# RESERVATION
@api_view(['GET'])
def get_reservations(request):
    reservations = Reservation.objects.all()
    serialized_reservations = ReservationSerializer(reservations, many=True)
    return Response(serialized_reservations.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_reservation(request):
    serialized_data = ReservationSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# COMPTE
@api_view(['GET'])
def get_comptes(request):
    comptes = Compte.objects.all()
    serialized_comptes = CompteSerializer(comptes, many=True)
    return Response(serialized_comptes.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_compte(request):
    serialized_data = CompteSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# TRANSACTION
@api_view(['GET'])
def get_transactions(request):
    transactions = Transaction.objects.all()
    serialized_transactions = TransactionSerializer(transactions, many=True)
    return Response(serialized_transactions.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_transaction(request):
    serialized_data = TransactionSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# PRODUIT
@api_view(['GET'])
def get_produits(request):
    produits = Produit.objects.all()
    serialized_produits = ProduitSerializer(produits, many=True)
    return Response(serialized_produits.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_produit(request):
    serialized_data = ProduitSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# COMMANDE CLIENT
@api_view(['GET'])
def get_commandes_clients(request):
    commandes = CommandeClient.objects.all()
    serialized_commandes = CommandeClientSerializer(commandes, many=True)
    return Response(serialized_commandes.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_commande_client(request):
    serialized_data = CommandeClientSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# LIGNE COMMANDE CLIENT
@api_view(['GET'])
def get_lignes_commande_client(request):
    lignes = LigneCommandeClient.objects.all()
    serialized_lignes = LigneCommandeClientSerializer(lignes, many=True)
    return Response(serialized_lignes.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_ligne_commande_client(request):
    serialized_data = LigneCommandeClientSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# COMMANDE FOURNISSEUR
@api_view(['GET'])
def get_commandes_fournisseurs(request):
    commandes = CommandeFournisseur.objects.all()
    serialized_commandes = CommandeFournisseurSerializer(commandes, many=True)
    return Response(serialized_commandes.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_commande_fournisseur(request):
    serialized_data = CommandeFournisseurSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# STOCK MAGASIN
@api_view(['GET'])
def get_stocks_magasin(request):
    stocks = StockMagasin.objects.all()
    serialized_stocks = StockMagasinSerializer(stocks, many=True)
    return Response(serialized_stocks.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_stock_magasin(request):
    serialized_data = StockMagasinSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# STOCK CUISINE
@api_view(['GET'])
def get_stocks_cuisine(request):
    stocks = StockCuisine.objects.all()
    serialized_stocks = StockCuisineSerializer(stocks, many=True)
    return Response(serialized_stocks.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_stock_cuisine(request):
    serialized_data = StockCuisineSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# INVENTAIRE MAGASIN
@api_view(['GET'])
def get_inventaires_magasin(request):
    inventaires = InventaireMagasin.objects.all()
    serialized_inventaires = InventaireMagasinSerializer(inventaires, many=True)
    return Response(serialized_inventaires.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_inventaire_magasin(request):
    serialized_data = InventaireMagasinSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# INVENTAIRE CUISINE
@api_view(['GET'])
def get_inventaires_cuisine(request):
    inventaires = InventaireCuisine.objects.all()
    serialized_inventaires = InventaireCuisineSerializer(inventaires, many=True)
    return Response(serialized_inventaires.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_inventaire_cuisine(request):
    serialized_data = InventaireCuisineSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)




# LIGNE INVENTAIRE MAGASIN
@api_view(['GET'])
def get_lignes_inventaire_magasin(request):
    lignes = LigneInventaireMagasin.objects.all()
    serialized_lignes = LigneInventaireMagasinSerializer(lignes, many=True)
    return Response(serialized_lignes.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_ligne_inventaire_magasin(request):
    serialized_data = LigneInventaireMagasinSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)



# LIGNE INVENTAIRE CUISINE
@api_view(['GET'])
def get_lignes_inventaire_cuisine(request):
    lignes = LigneInventaireCuisine.objects.all()
    serialized_lignes = LigneInventaireCuisineSerializer(lignes, many=True)
    return Response(serialized_lignes.data, status=status.HTTP_200_OK)


@api_view(['POST'])
def create_ligne_inventaire_cuisine(request):
    serialized_data = LigneInventaireCuisineSerializer(data=request.data)
    
    if serialized_data.is_valid():
        serialized_data.save()
        return Response(serialized_data.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serialized_data.errors, status=status.HTTP_400_BAD_REQUEST)


